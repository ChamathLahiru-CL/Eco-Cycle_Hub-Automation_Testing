package pageMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class productPage {

    public void viewDetails(WebDriver driver){
        driver.findElement(By.xpath("//button[contains(text(),'Details')]")).click();
    }

    public void normalAddToCart(WebDriver driver){
        driver.findElement(By.xpath("//button[contains(text(),'Add to Cart')]")).click();
    }

    public void viewAddToCart(WebDriver driver){
        driver.findElement(By.xpath("//button[contains(text(),'Details')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Add to Cart')]")).click();
    }

    public void openShoppingCart(WebDriver driver){
        driver.findElement(By.xpath("//a[@href='/cart']")).click();
    }

    public void checkOrders(WebDriver driver){
        driver.findElement(By.xpath("//a[@href='/orders']")).click();
    }

    public void backHome(WebDriver driver){
        driver.findElement(By.xpath("//button[text()='Back Home']")).click();
    }

    public void notification(WebDriver driver){
        driver.findElement(By.xpath("//a[@href='/shop-notifications']")).click();
    }

    public void user(WebDriver driver){
        driver.findElement(By.xpath("//img[@alt='User']")).click();
    }

    public void logOut(WebDriver driver){
        driver.findElement(By.xpath("//img[@alt='User']")).click();
        driver.findElement(By.xpath("//div[contains(text(),'Logout')]")).click();
    }

    public void userProfile(WebDriver driver){
        driver.findElement(By.xpath("//img[@alt='User']")).click();
        driver.findElement(By.xpath("//a[@href='/customer-profile']")).click();
    }

}
