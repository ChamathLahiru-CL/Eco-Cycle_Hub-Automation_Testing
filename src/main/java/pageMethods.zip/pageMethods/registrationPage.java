package pageMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class registrationPage {

    public void createAccount(WebDriver driver, String name, String email, String password, String phone, String address, String city, String zipcode){

        driver.findElement(By.linkText("Explore Shop Products")).click();
        driver.findElement(By.cssSelector("a[href='/register?type=customer']")).click();

        driver.navigate().refresh();
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.cssSelector("input[placeholder='Create a password']")).sendKeys(password);
        driver.findElement(By.cssSelector("input[placeholder='Enter your phone number']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@id='address']")).sendKeys(address);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("zipCode")).sendKeys(zipcode);
        driver.findElement(By.xpath("//button[text()='Create account']")).click();

    }

    public void validateName (WebDriver driver, String name, String email, String password, String phone, String address, String city, String zipcode){

        driver.findElement(By.linkText("Explore Shop Products")).click();
        driver.findElement(By.cssSelector("a[href='/register?type=customer']")).click();

        driver.navigate().refresh();
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.cssSelector("input[placeholder='Create a password']")).sendKeys(password);
        driver.findElement(By.cssSelector("input[placeholder='Enter your phone number']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@id='address']")).sendKeys(address);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("zipCode")).sendKeys(zipcode);
        driver.findElement(By.xpath("//button[text()='Create account']")).click();

    }

    public void validateEmail (WebDriver driver, String name, String email, String password, String phone, String address, String city, String zipcode){

        driver.findElement(By.linkText("Explore Shop Products")).click();
        driver.findElement(By.cssSelector("a[href='/register?type=customer']")).click();

        driver.navigate().refresh();
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.cssSelector("input[placeholder='Create a password']")).sendKeys(password);
        driver.findElement(By.cssSelector("input[placeholder='Enter your phone number']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@id='address']")).sendKeys(address);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("zipCode")).sendKeys(zipcode);
        driver.findElement(By.xpath("//button[text()='Create account']")).click();

    }

    public void validatePassword (WebDriver driver, String name, String email, String password, String phone, String address, String city, String zipcode){

        driver.findElement(By.linkText("Explore Shop Products")).click();
        driver.findElement(By.cssSelector("a[href='/register?type=customer']")).click();

        driver.navigate().refresh();
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.cssSelector("input[placeholder='Create a password']")).sendKeys(password);
        driver.findElement(By.cssSelector("input[placeholder='Enter your phone number']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@id='address']")).sendKeys(address);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("zipCode")).sendKeys(zipcode);
        driver.findElement(By.xpath("//button[text()='Create account']")).click();

    }

    public void validateWeekPassword (WebDriver driver, String name, String email, String password, String phone, String address, String city, String zipcode){

        driver.findElement(By.linkText("Explore Shop Products")).click();
        driver.findElement(By.cssSelector("a[href='/register?type=customer']")).click();

        driver.navigate().refresh();
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.cssSelector("input[placeholder='Create a password']")).sendKeys(password);
        driver.findElement(By.cssSelector("input[placeholder='Enter your phone number']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@id='address']")).sendKeys(address);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("zipCode")).sendKeys(zipcode);
        driver.findElement(By.xpath("//button[text()='Create account']")).click();

    }

    public void validateSameEmail (WebDriver driver, String name, String email, String password, String phone, String address, String city, String zipcode){

        driver.findElement(By.linkText("Explore Shop Products")).click();
        driver.findElement(By.cssSelector("a[href='/register?type=customer']")).click();

        driver.navigate().refresh();
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.cssSelector("input[placeholder='Create a password']")).sendKeys(password);
        driver.findElement(By.cssSelector("input[placeholder='Enter your phone number']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@id='address']")).sendKeys(address);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("zipCode")).sendKeys(zipcode);
        driver.findElement(By.xpath("//button[text()='Create account']")).click();

    }
}
