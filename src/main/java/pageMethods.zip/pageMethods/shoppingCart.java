package pageMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class shoppingCart {

    public void continueShopping(WebDriver driver){
        driver.findElement(By.xpath("//a[contains(text(),'Continue Shopping')]")).click();
    }

    public void checkout(WebDriver driver){
        driver.findElement(By.xpath("//button[contains(text(),'Proceed to Stripe Checkout')]")).click();
    }

    public void backToProducts(WebDriver driver){
        driver.findElement(By.xpath("//a[span[text()='Back to Products']]")).click();
    }

    public void incrementProduct(WebDriver driver){
        driver.findElement(By.xpath("//button[.//*[name()='svg' and contains(@class,'lucide-plus')]]")).click();
    }

    public void decrementProduct(WebDriver driver){
        driver.findElement(By.xpath("//button[.//*[name()='svg' and contains(@class,'lucide-minus')]]")).click();
    }

    public void deleteProduct(WebDriver driver){
        driver.findElement(By.xpath("//button[.//*[name()='svg' and contains(@class,'lucide-trash2')]]")).click();
    }

}
